<?php

$con=connect("localhost","root","","vit") OR die('Network connection error. Check connection then reload');

 ?>